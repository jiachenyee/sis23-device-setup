import SwiftUI

struct ContentView: View {
    
    let questions = [Question(name: "Sample Question", answer: false)]
    var body: some View {
        VStack {
            // insert your code here!
        }
    }
}
