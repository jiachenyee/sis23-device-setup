import SwiftUI

struct Question {
    var name: String
    var answer: Bool
}
