# CowML
## An image recognition app with CoreML and SwiftUI.

![iPhone 14 Pro - Simulator  2023-01-30 at 05 39 18 PM](https://user-images.githubusercontent.com/36725840/215441369-9622ee7e-3ef3-4c05-804b-4de4485d9ece.png)
