//
//  CowMLApp.swift
//  CowML
//
//  Created by Jia Chen Yee on 21/11/22.
//

import SwiftUI

@main
struct CowMLApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
