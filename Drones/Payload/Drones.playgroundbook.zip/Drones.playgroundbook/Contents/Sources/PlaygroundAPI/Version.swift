public func getDateVersion() -> String {
    return "2-28 09:50:07"
}

public func getBuild() -> Int {
    return 333
}

public func getGitHash() -> String {
    return "40ffbb7"
}
