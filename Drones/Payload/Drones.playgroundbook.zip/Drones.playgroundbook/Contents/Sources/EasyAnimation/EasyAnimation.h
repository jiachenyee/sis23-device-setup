//
//  EasyAnimation.h
//  EasyAnimation
//
//  Created by Ian Ynda-Hummel on 8/26/15.
//  Copyright (c) 2015 EasyAnimation. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for EasyAnimation.
FOUNDATION_EXPORT double EasyAnimationVersionNumber;

//! Project version string for EasyAnimation.
FOUNDATION_EXPORT const unsigned char EasyAnimationVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EasyAnimation/PublicHeader.h>
