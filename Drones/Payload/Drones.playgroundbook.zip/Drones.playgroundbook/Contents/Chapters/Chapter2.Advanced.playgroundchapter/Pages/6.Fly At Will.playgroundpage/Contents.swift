//#-hidden-code
import UIKit
import PlaygroundSupport

//#-code-completion(everything, hide)
//#-code-completion(description, show, "[Int]")
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, show, takeOff(), land(), wait(seconds:))
//#-code-completion(identifier, show, flyUp(cm:), flyDown(cm:))
//#-code-completion(identifier, show, flyForward(cm:), flyBackward(cm:))
//#-code-completion(identifier, show, turnRight(degree:), turnLeft(degree:))
//#-code-completion(identifier, show, getHeight())
//#-code-completion(identifier, show, setSpeed(cms:))
//#-code-completion(identifier, show, flyLine(x:y:z:))
//#-code-completion(identifier, show, flyCurve(x1:y1:z1:x2:y2:z2:))
//#-code-completion(identifier, show, if, func, for, while, (, ), (), var, let, ., =, <, >, ==, !=, +=, +, -, >=, <=, true, false, &&, ||, !)


_setupOneDroneEnv()
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
*/

//#-editable-code Tap to enter code.
takeOff()
land()
//#-end-editable-code

//#-hidden-code
_cleanOneDroneEnv()
//#-end-hidden-code
