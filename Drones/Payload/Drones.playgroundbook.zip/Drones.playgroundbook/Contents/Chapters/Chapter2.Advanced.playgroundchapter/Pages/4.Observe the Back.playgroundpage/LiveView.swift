import PlaygroundSupport

_setup(storyboardName: "Chapter2_4")
