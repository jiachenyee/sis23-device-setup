//#-hidden-code
import UIKit
import PlaygroundSupport

//#-code-completion(everything, hide)
//#-code-completion(literal, show, array)
//#-code-completion(currentmodule, show)
//#-code-completion(description, show, "[Int]")
//#-code-completion(identifier, show, if, func, for, while, (, ), (), var, let, ., =, <, >, ==, !=, +=, +, -, >=, <=, true, false, swarm, tellos, &&, ||, !)

//#-code-completion(identifier, show, takeOff(), land(), wait(seconds:))
//#-code-completion(identifier, show, flyForward(cm:), flyBackward(cm:))
//#-code-completion(identifier, show, turnRight(degree:), turnLeft(degree:))
//#-code-completion(identifier, show, sync(seconds:))
//#-code-completion(identifier, show, transit(x:y:z:pad1:pad2:))

_setupMultipleDronesEnv()
let swarm = TelloManager
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 */

//#-editable-code Tap to enter code.

//#-end-editable-code

//#-hidden-code
_cleanOneDroneEnv()
//#-end-hidden-code
